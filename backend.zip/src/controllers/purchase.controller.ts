import { Request, Response } from 'express';
import { purchaseService } from '../services/purchase.service';
import { sendSuccess, sendCreated, sendNotFound, sendError } from '../utils/response';
import { AuthenticatedRequest } from '../middleware/auth';

export class PurchaseController {
  async getOrders(req: Request, res: Response) { try { sendSuccess(res, await purchaseService.getOrders(req.query as any)); } catch (e: any) { sendError(res, e.message); } }
  async getOrderById(req: Request, res: Response) {
    try { const o = await purchaseService.getOrderById(req.params.id); o ? sendSuccess(res, o) : sendNotFound(res, 'Purchase order'); } catch (e: any) { sendError(res, e.message); }
  }
  async createOrder(req: AuthenticatedRequest, res: Response) { try { sendCreated(res, await purchaseService.createOrder(req.body, req.user!.id)); } catch (e: any) { sendError(res, e.message, 400); } }
  async updateOrder(req: Request, res: Response) {
    try { const o = await purchaseService.updateOrder(req.params.id, req.body); o ? sendSuccess(res, o, 'Updated') : sendNotFound(res, 'PO'); } catch (e: any) { sendError(res, e.message, 400); }
  }
  async getInvoices(req: Request, res: Response) { try { sendSuccess(res, await purchaseService.getInvoices(req.query as any)); } catch (e: any) { sendError(res, e.message); } }
  async createInvoice(req: AuthenticatedRequest, res: Response) { try { sendCreated(res, await purchaseService.createInvoice(req.body, req.user!.id)); } catch (e: any) { sendError(res, e.message, 400); } }
}

export const purchaseController = new PurchaseController();
