import { AppDataSource } from '../config/data-source';
import { TallySync } from '../entities/TallySync';

export class TallyService {
  private repo = AppDataSource.getRepository(TallySync);

  async getPending() {
    return this.findAll({ sync_status: 'pending' });
  }

  async create(data: any) {
    const record = this.repo.create(data);
    return this.repo.save(record);
  }

  async updateStatus(id: string, status: string, errorMessage?: string) {
    const record = await this.repo.findOneBy({ id });
    if (!record) return null;
    record.sync_status = status;
    if (errorMessage) {
      record.error_message = errorMessage;
    }
    if (status === 'synced') {
      record.synced_at = new Date();
    }
    return this.repo.save(record);
  }

  async findAll(filters: { sync_status?: string; record_type?: string; start_date?: string; end_date?: string }) {
    const qb = this.repo.createQueryBuilder('ts');
    if (filters.sync_status) qb.andWhere('ts.sync_status = :ss', { ss: filters.sync_status });
    if (filters.record_type) qb.andWhere('ts.record_type = :rt', { rt: filters.record_type });
    if (filters.start_date) qb.andWhere('ts.invoice_date >= :start', { start: filters.start_date });
    if (filters.end_date) qb.andWhere('ts.invoice_date <= :end', { end: filters.end_date });
    qb.orderBy('ts.created_at', 'DESC');
    return qb.getMany();
  }

  async markSynced(id: string) {
    const record = await this.repo.findOneBy({ id });
    if (!record) return null;
    record.sync_status = 'synced';
    record.synced_at = new Date();
    return this.repo.save(record);
  }

  async markFailed(id: string, errorMessage: string) {
    const record = await this.repo.findOneBy({ id });
    if (!record) return null;
    record.sync_status = 'failed';
    record.error_message = errorMessage;
    return this.repo.save(record);
  }

  async getExportData(filters: { sync_status?: string; record_type?: string }) {
    const records = await this.findAll(filters);
    return {
      records,
      exportDate: new Date().toISOString(),
      totalRecords: records.length,
    };
  }
}

export const tallyService = new TallyService();
