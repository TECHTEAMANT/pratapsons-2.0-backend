import { AppDataSource } from '../config/data-source';
import { BarcodeBatch } from '../entities/BarcodeBatch';
import { BarcodeSequence } from '../entities/BarcodeSequence';
import { encodeCost } from '../utils/costEncoding';
import { ILike } from 'typeorm';
import logger from '../utils/logger';

export class InventoryService {
  private batchRepo = AppDataSource.getRepository(BarcodeBatch);
  private seqRepo = AppDataSource.getRepository(BarcodeSequence);

  async findAll(filters: { status?: string; vendor?: string; product_group?: string; floor?: string; search?: string; page?: number; limit?: number }) {
    const page = filters.page || 1;
    const limit = filters.limit || 50;
    const skip = (page - 1) * limit;

    const qb = this.batchRepo.createQueryBuilder('bb');

    if (filters.status) qb.andWhere('bb.status = :status', { status: filters.status });
    if (filters.vendor) qb.andWhere('bb.vendor = :vendor', { vendor: filters.vendor });
    if (filters.product_group) qb.andWhere('bb.product_group = :pg', { pg: filters.product_group });
    if (filters.floor) qb.andWhere('bb.floor = :floor', { floor: filters.floor });
    if (filters.search) {
      qb.andWhere('(bb.barcode_alias_8digit ILIKE :search OR bb.design_no ILIKE :search)', { search: `%${filters.search}%` });
    }

    qb.orderBy('bb.created_at', 'DESC').skip(skip).take(limit);

    const [data, total] = await qb.getManyAndCount();
    return { data, total, page, limit };
  }

  async findById(id: string) {
    return this.batchRepo.findOne({ where: { id }, relations: ['printLogs'] });
  }

  async searchByBarcode(barcode: string) {
    if (!barcode) return [];
    return this.batchRepo.find({
      where: [
        { barcode_alias_8digit: ILike(`%${barcode}%`) },
        { barcode_structured: ILike(`%${barcode}%`) },
      ],
      take: 20,
    });
  }

  async create(data: any, userId: string) {
    return AppDataSource.transaction(async (manager) => {
      // Get and increment barcode sequence
      let seq = await manager.findOne(BarcodeSequence, { where: { id: 1 } });
      if (!seq) {
        seq = manager.create(BarcodeSequence, { id: 1, last_number: 10000000 });
      }
      const nextNumber = Number(seq.last_number) + 1;
      seq.last_number = nextNumber;
      await manager.save(seq);

      const alias = nextNumber.toString().padStart(8, '0');

      // Build structured barcode
      const parts = [data.vendor || '', data.design_no || '', data.size || '', data.color || ''];
      const structured = parts.join('-') + `-${alias}`;

      // Encode cost
      const costEncoded = data.cost_actual ? encodeCost(data.cost_actual) : null;

      const batch = manager.create(BarcodeBatch, {
        barcode_alias_8digit: alias || '',
        barcode_structured: structured,
        design_no: data.design_no || '',
        product_group: data.product_group || undefined,
        size: data.size || undefined,
        color: data.color || undefined,
        vendor: data.vendor || undefined,
        payout_code: data.payout_code || undefined,
        cost_actual: data.cost_actual || 0,
        cost_encoded: costEncoded || undefined,
        mrp: data.mrp || 0,
        hsn_code: data.hsn_code || null,
        gst_logic: data.gst_logic || 'AUTO_5_18',
        total_quantity: data.total_quantity || 0,
        available_quantity: data.total_quantity || 0,
        floor: data.floor || null,
        po_id: data.po_id || null,
        description: data.description || null,
        created_by: userId,
      });

      const saved = await manager.save(batch);
      logger.info(`Created barcode batch: ${alias}`, { design: data.design_no, qty: data.total_quantity });
      return saved;
    });
  }

  async update(id: string, data: Record<string, any>, userId: string) {
    const batch = await this.batchRepo.findOneBy({ id });
    if (!batch) return null;

    const allowed = ['design_no', 'product_group', 'size', 'color', 'vendor', 'payout_code', 'cost_actual', 'mrp', 'hsn_code', 'gst_logic', 'floor', 'discount_type', 'discount_value', 'discount_start_date', 'discount_end_date', 'status', 'description', 'photos'];
    for (const key of allowed) {
      if (data[key] !== undefined) (batch as any)[key] = data[key];
    }

    if (data.cost_actual !== undefined) {
      batch.cost_encoded = encodeCost(data.cost_actual);
    }
    batch.modified_by = userId;

    return this.batchRepo.save(batch);
  }

  async adjustQuantity(id: string, adjustment: number, userId: string) {
    const batch = await this.batchRepo.findOneBy({ id });
    if (!batch) return null;

    batch.available_quantity += adjustment;
    if (batch.available_quantity < 0) batch.available_quantity = 0;
    batch.modified_by = userId;

    return this.batchRepo.save(batch);
  }

  async moveToFloor(id: string, floorId: string, userId: string) {
    const batch = await this.batchRepo.findOneBy({ id });
    if (!batch) return null;

    batch.floor = floorId;
    batch.modified_by = userId;

    return this.batchRepo.save(batch);
  }
}

export const inventoryService = new InventoryService();
