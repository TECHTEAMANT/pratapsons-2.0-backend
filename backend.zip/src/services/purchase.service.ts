import { AppDataSource } from '../config/data-source';
import { PurchaseOrder } from '../entities/PurchaseOrder';
import { PurchaseInvoice } from '../entities/PurchaseInvoice';
import { ILike } from 'typeorm';

export class PurchaseService {
  private poRepo = AppDataSource.getRepository(PurchaseOrder);

  async getOrders(filters: { vendor_id?: string; status?: string; search?: string }) {
    const qb = this.poRepo.createQueryBuilder('po').leftJoinAndSelect('po.vendor', 'v');
    if (filters.vendor_id) qb.andWhere('po.vendor_id = :vid', { vid: filters.vendor_id });
    if (filters.status) qb.andWhere('po.status = :status', { status: filters.status });
    if (filters.search) qb.andWhere('(po.order_number ILIKE :s OR v.name ILIKE :s)', { s: `%${filters.search}%` });
    qb.orderBy('po.created_at', 'DESC');
    return qb.getMany();
  }

  async getOrderById(id: string) {
    return this.poRepo.findOne({ where: { id }, relations: ['items', 'vendor'] });
  }

  async createOrder(data: any, userId: string) {
    const count = await this.poRepo.count();
    const poNum = `PO${new Date().getFullYear()}${(count + 1).toString().padStart(6, '0')}`;
    const po = this.poRepo.create({
      order_number: poNum,
      vendor_id: data.vendor_id,
      order_date: data.order_date,
      taxable_value: data.taxable_value || 0,
      manual_gst_amount: data.manual_gst_amount || null,
      total_amount: data.total_amount || 0,
      notes: data.notes || null,
      created_by: userId,
    });
    return this.poRepo.save(po);
  }

  async updateOrder(id: string, data: Record<string, any>) {
    const po = await this.poRepo.findOneBy({ id });
    if (!po) return null;
    const allowed = ['status', 'taxable_value', 'manual_gst_amount', 'total_amount', 'notes', 'vendor_invoice_attachment', 'gst_difference_reason'];
    for (const key of allowed) { if (data[key] !== undefined) (po as any)[key] = data[key]; }
    return this.poRepo.save(po);
  }

  async getInvoices(filters: { vendor_id?: string }) {
    const repo = AppDataSource.getRepository(PurchaseInvoice);
    const where: any = {};
    if (filters.vendor_id) where.vendor_id = filters.vendor_id;
    return repo.find({ where, order: { created_at: 'DESC' } });
  }

  async createInvoice(data: any, userId: string) {
    const repo = AppDataSource.getRepository(PurchaseInvoice);
    const inv = repo.create({
      vendor_id: data.vendor_id,
      invoice_number: data.invoice_number,
      invoice_date: data.invoice_date,
      total_amount: data.total_amount,
      notes: data.notes || null,
      created_by: userId,
    });
    return repo.save(inv);
  }
}

export const purchaseService = new PurchaseService();
