import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  ManyToOne,
  JoinColumn,
  CreateDateColumn,
} from 'typeorm';
import { PurchaseOrder } from './PurchaseOrder';
import { ProductGroup } from './ProductGroup';
import { Color } from './Color';
import { Size } from './Size';

@Entity('purchase_items')
export class PurchaseItem {
  @PrimaryGeneratedColumn('uuid')
  id!: string;

  @Column({ type: 'uuid' })
  po_id!: string;

  @ManyToOne(() => PurchaseOrder, { onDelete: 'CASCADE' })
  @JoinColumn({ name: 'po_id' })
  purchase_order!: PurchaseOrder;

  @Column({ type: 'text' })
  design_no!: string;

  @Column({ type: 'uuid' })
  product_group!: string;

  @ManyToOne(() => ProductGroup)
  @JoinColumn({ name: 'product_group' })
  product_group_ref!: ProductGroup;

  @Column({ type: 'uuid', nullable: true })
  color!: string | null;

  @ManyToOne(() => Color, { nullable: true })
  @JoinColumn({ name: 'color' })
  color_ref!: Color | null;

  @Column({ type: 'uuid' })
  size!: string;

  @ManyToOne(() => Size)
  @JoinColumn({ name: 'size' })
  size_ref!: Size;

  @Column({ type: 'integer', default: 0 })
  quantity!: number;

  @Column({ type: 'decimal', precision: 10, scale: 2, default: 0 })
  cost_per_item!: number;

  @Column({ type: 'decimal', precision: 10, scale: 2, default: 0 })
  mrp!: number;

  @Column({ type: 'decimal', precision: 10, scale: 2, default: 0 })
  mrp_markup_percent!: number;

  @Column({ type: 'text', default: 'AUTO_5_18' })
  gst_logic!: string;

  @Column({ type: 'text', nullable: true })
  description!: string;

  @Column({ type: 'text', nullable: true })
  order_number!: string;

  @Column({ type: 'text', nullable: true })
  hsn_code!: string;

  @Column({ type: 'uuid', nullable: true })
  floor_id!: string | null;

  @CreateDateColumn({ type: 'timestamptz' })
  created_at!: Date;
}
