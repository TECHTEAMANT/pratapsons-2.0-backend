import { Entity, PrimaryGeneratedColumn, Column, CreateDateColumn, UpdateDateColumn, OneToMany } from 'typeorm';
import { BarcodePrintLog } from './BarcodePrintLog';

@Entity('barcode_batches')
export class BarcodeBatch {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column({ type: 'text', unique: true })
  barcode_alias_8digit: string;

  @Column({ type: 'text', nullable: true })
  barcode_structured: string;

  @Column({ type: 'text' })
  design_no: string;

  @Column({ type: 'text', nullable: true })
  product_group: string;

  @Column({ type: 'text', nullable: true })
  size: string;

  @Column({ type: 'text', nullable: true })
  color: string;

  @Column({ type: 'text', nullable: true })
  vendor: string;

  @Column({ type: 'text', nullable: true })
  payout_code: string;

  @Column({ type: 'numeric', default: 0 })
  cost_actual: number;

  @Column({ type: 'text', nullable: true })
  cost_encoded: string;

  @Column({ type: 'numeric', default: 0 })
  mrp: number;

  @Column({ type: 'text', nullable: true })
  hsn_code: string;

  @Column({ type: 'text', default: 'AUTO_5_18' })
  gst_logic: string;

  @Column({ type: 'int', default: 0 })
  total_quantity: number;

  @Column({ type: 'int', default: 0 })
  available_quantity: number;

  @Column({ type: 'text', nullable: true })
  floor: string;

  @Column({ type: 'text', nullable: true })
  discount_type: string;

  @Column({ type: 'numeric', nullable: true })
  discount_value: number;

  @Column({ type: 'date', nullable: true })
  discount_start_date: Date;

  @Column({ type: 'date', nullable: true })
  discount_end_date: Date;

  @Column({ type: 'text', default: 'active' })
  status: string;

  @Column({ type: 'uuid', nullable: true })
  po_id: string;

  @Column({ type: 'text', array: true, default: '{}' })
  photos: string[];

  @Column({ type: 'text', nullable: true })
  description: string;

  @Column({ type: 'uuid', nullable: true })
  created_by: string;

  @Column({ type: 'uuid', nullable: true })
  modified_by: string;

  @CreateDateColumn({ type: 'timestamptz' })
  created_at: Date;

  @UpdateDateColumn({ type: 'timestamptz' })
  updated_at: Date;

  // Relations
  @OneToMany(() => BarcodePrintLog, log => log.barcodeBatch)
  printLogs: BarcodePrintLog[];
}
