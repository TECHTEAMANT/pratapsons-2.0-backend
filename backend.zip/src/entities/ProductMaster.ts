import { Entity, PrimaryGeneratedColumn, Column, CreateDateColumn, UpdateDateColumn } from 'typeorm';

@Entity('product_masters')
export class ProductMaster {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column({ type: 'text' })
  design_no: string;

  @Column({ type: 'text', nullable: true })
  product_group: string;

  @Column({ type: 'text', nullable: true })
  color: string;

  @Column({ type: 'text', nullable: true })
  vendor: string;

  @Column({ type: 'numeric', default: 0 })
  mrp: number;

  @Column({ type: 'text', default: 'AUTO_5_18' })
  gst_logic: string;

  @Column({ type: 'text', nullable: true })
  hsn_code: string;

  @Column({ type: 'text', nullable: true })
  floor: string;

  @Column({ type: 'text', array: true, default: '{}' })
  photos: string[];

  @Column({ type: 'text', default: '' })
  description: string;

  @Column({ type: 'int', default: 1 })
  barcodes_per_item: number;

  @Column({ type: 'uuid', nullable: true })
  created_by: string;

  @CreateDateColumn({ type: 'timestamptz' })
  created_at: Date;

  @UpdateDateColumn({ type: 'timestamptz' })
  updated_at: Date;
}
